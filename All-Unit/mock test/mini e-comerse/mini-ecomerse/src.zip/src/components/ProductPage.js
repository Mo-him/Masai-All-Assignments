import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function ProductPage() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products")
      .then((response) => response.json())
      .then((data) => setProducts(data));
  }, []);

  return (
    <div>
      <h1>Products</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1rem" }}>
        {products.map((product) => (
          <Link key={product.id} to={`/product/${product.id}`}>
            <div style={{ border: "1px solid #ccc", padding: "1rem" }}>
              <img src={product.image} alt={product.title} style={{ maxWidth: "100%" }} />
              <h2>{product.brand}</h2>
              <h3>{product.title}</h3>
              <p>Category: {product.category}</p>
              <p>Price: {product.price}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default ProductPage;
