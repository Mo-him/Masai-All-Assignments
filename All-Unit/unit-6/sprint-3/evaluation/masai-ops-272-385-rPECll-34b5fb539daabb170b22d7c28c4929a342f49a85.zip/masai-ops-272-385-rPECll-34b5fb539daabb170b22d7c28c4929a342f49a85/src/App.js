export default function App() {
  return <div className="App">{/* add AllRoutes component */}</div>;
}
